package exercise1;

public class Test4 {
  public static void main(String[] args) {
    System.out.println("What'swrongwiththisprogram?");
  }
}
