package symmetricStrings;

import java.lang.StringBuffer;

public class SymString {
	private String str;
	private int temp = 0, flag = 0;

	public SymString(String paraStr) {
		str = paraStr;
	}

	StringBuffer strBuffer = new StringBuffer(str);

	public int getLength() {
		return (strBuffer.length());
	}

	public boolean isSymStr() {
		for (temp = 0; temp <= getLength(); temp++) {
			if (strBuffer.charAt(temp) == strBuffer.charAt(getLength() - (temp + 1))) {
				flag++;
			}
		}
		if (flag == getLength()) {
			return true;
		} else {
			return false;
		}
	}

	public boolean isSymStr2() {
		if (strBuffer.reverse().equals(strBuffer)) {
			return true;
		} else {
			return false;
		}
	}
}
