package symmetricStrings;

class TestSymStr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SymString Test1 = new SymString("lmfao let's try it out.");
		System.out.println("Is the string symmetric?");
		System.out.println(Test1.isSymStr2());
		System.out.println(Test1.isSymStr());
	}

}
