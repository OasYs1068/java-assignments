package exercise2;

interface Pet  {
	abstract String getName();
	abstract void setName(String name);
	abstract void play();
}
