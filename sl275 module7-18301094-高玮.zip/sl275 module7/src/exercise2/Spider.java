package exercise2;

public class Spider extends Animal {
		public Spider(){
			super(8);
		}
		
		public void eat() {
			System.out.println("Spider started eating.");
		}
		
}
